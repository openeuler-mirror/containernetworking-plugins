
This document has moved to the [containernetworking/cni.dev](https://github.com/containernetworking/cni.dev) repo.

You can find it online here: https://cni.dev/plugins/current/ipam/host-local/
